CREATE TABLE tblpage (
	ID int(10) auto_increment primary key,
  	PageType varchar(200) DEFAULT NULL,
  	PageTitle mediumtext DEFAULT NULL,
  	PageDescription mediumtext DEFAULT NULL,
  	Email varchar(200) DEFAULT NULL,
  	MobileNumber varchar(10) DEFAULT NULL,
  	UpdationDate date DEFAULT current_timestamp,
  	Timing varchar(200) NOT NULL
);

INSERT INTO tblpage (ID, PageType, PageTitle, PageDescription, Email, MobileNumber, Timing) VALUES
(1, 'aboutus', 'About Us', 'Our main focus is on quality and hygiene. Our Ayurveda and Panchakarma Centre is well equipped with advanced technology equipments and provides best quality services. Our staff is well trained and experienced, offering advanced services in Skin, Hair and Body Shaping that will provide you with a luxurious experience that leave you feeling relaxed and stress free. The specialties in our Centre are Panchkarma & Suvarn Prashan for kids, Garbh Sanskar therapy for pregnant ladies.', NULL, NULL, NULL),
(2, 'contactus', 'Contact Us', 'Dr. Mrs. Ashiwini Joshi<br>Kirti Society, 11/2, near Sanjay Kale ground, Central Excise Staff Colony, Sector No. 28, Pradhikaran, Nigdi, Pune, Pimpri-Chinchwad, Maharashtra 411044', 'admin@gmail.com', '9763701672', '10:30 am to 7:30 pm');

CREATE TABLE tbladmin (
	ID int(10) auto_increment primary key,
  	AdminName char(50) DEFAULT NULL,
  	UserName char(50) DEFAULT NULL,
  	MobileNumber varchar(10) DEFAULT NULL,
  	Email varchar(200) DEFAULT NULL,
  	Password varchar(200) DEFAULT NULL,
  	AdminRegdate timestamp NULL DEFAULT current_timestamp()
);

INSERT INTO tbladmin (ID, AdminName, UserName, MobileNumber, Email, Password) VALUES
(1, 'Madhura Mudkhedkar', 'admin', '7898799798', 'admin@gmail.com', 'admin');

CREATE TABLE tbluser (
  ID int(10) auto_increment primary key,
  FirstName varchar(120) DEFAULT NULL,
  LastName varchar(250) DEFAULT NULL,
  MobileNumber varchar(10) DEFAULT NULL,
  Email varchar(120) DEFAULT NULL,
  Password varchar(120) DEFAULT NULL,
  RegDate timestamp DEFAULT current_timestamp()
);

INSERT INTO tbluser (FirstName, LastName, MobileNumber, Email, Password) VALUES
('Shilpa','Shetty','9823787898','iamshilpashetty@gmail.com','test2024'),
('Tanishka','Bhosale','8823787898','tannu.2006@gmail.com','test2024'),
('Rutuja','Datar','9823787888','rutu.2005@gmail.com','test2024'),
('Abhay','Kulkarni','9823788898','kuls.abhay@gmail.com','test2024'),
('Priyanka','Singh','9823788888','pinkoo.singh@gmail.com','test2024'),
('Ajay','Avasthi','7873787898','iamfrompune@gmail.com','test2024'),
('Divya','Pandit','9822287898','pandit.d@gmail.com','test2024'),
('Prathamesh','Kale','9823557898','pratham2000@gmail.com','test2024'),
('Aparna','Joshi','9823787555','joshi.appu@gmail.com','test2024'),
('Neha','Bombale','9822290095','iambombale19@gmail.com','test2024'),
('John','Mathew','7823787898','john.mathew@gmail.com','test2024'),
('Ganesh','Walvekar','7723787898','ganesh.w2001@gmail.com','test2024'),
('Nikita','Shinde','7773787898','nikki1998@gmail.com','test2024'),
('Amol','Desai','8823887898','desai.@gmail.com','test2024');

CREATE TABLE tblservices (
	ID int(10) auto_increment primary key,
  	ServiceName varchar(200) DEFAULT NULL,
  	ServiceDescription mediumtext DEFAULT NULL,
  	Cost int(10) DEFAULT NULL,
  	Image varchar(200) DEFAULT NULL,
  	CreationDate timestamp DEFAULT current_timestamp()
);

INSERT INTO tblservices (ServiceName, ServiceDescription, Cost, Image) VALUES
('Garbh Sanskar','',450,''),
('Snehan (Massage)','',450,''),
('Svedan','',450,''),
('Pind Sved','',450,''),
('Kadhi Basti','',450,''),
('Suvarna Prashan','',450,''),
('Janu Basti','',450,''),
('Shirodhara','',450,''),
('Agni Karma','',450,''),
('Panchkarma (Vaman)','',450,''),
('Panchkarma (Virechan + Basti)','',450,''),
('Panchkarma (Nasya)','',450,''),
('Panchkarma (Rakta Mokshan)','',450,'');




